from django.apps import AppConfig


class FoodtaskerappConfig(AppConfig):
    name = 'foodtaskerapp'
